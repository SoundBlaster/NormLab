"""One-off frozen matched probe driver; no automatic resume or retry."""
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

repo = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(repo / "evaluation"))
from responses_runtime import task_digest

os.umask(0o077)
source = repo / "fixtures/providers/stage1-choice.json"
data = json.loads(source.read_bytes())
assert task_digest(data) == "dedfab0c194443cb8523dfb05e614918981f15e45c03cbd0cf8c8f3eb76373e8"
assert os.environ.get("COREINFRA_API_KEY")
run = root / "capture"
run.mkdir(mode=0o700, exist_ok=False)
source_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert source_commit == "2a89c8e4c091cdd800fa591401eb77d83cf65298"
arms = [("jev", "provider_smoke.py", "coreinfra-jev"),
        ("decisions", "provider_smoke.py", "coreinfra-decisions"),
        ("responses", "responses_smoke.py", "coreinfra-responses")]
index = {"schema": "normlab.current-sdk-matched-probe/v1", "protocolCommit": source_commit,
    "executableBase": "32d4a4eb418adb36131d156618742a003a4209fa",
    "semanticTaskDigest": task_digest(data),
    "inputFileSha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "protocolFileSha256": hashlib.sha256((repo / "docs/CURRENT_SDK_MATCHED_PROBE_2026-10-18.md").read_bytes()).hexdigest(),
    "driverSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "startedAt": datetime.now(timezone.utc).isoformat(), "maxRequests": 3,
    "automaticRetries": 0, "wallDeadlineSeconds": 120,
    "externalCeilingUsdUserReported": 4, "externalCeilingIndependentlyVerified": False,
    "candidateReference": "incompatible", "candidateReferenceIsIndependentHumanGold": False,
    "arms": [{"id": a, "provider": p, "status": "not-executed"} for a, _, p in arms]}
def checkpoint():
    tmp = run / "index.tmp"
    tmp.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n")
    tmp.replace(run / "index.json")
checkpoint()
started = time.monotonic()
for i, (arm, script, preset) in enumerate(arms):
    remaining = 120 - (time.monotonic() - started)
    if remaining <= 0:
        index["stopReason"] = "outer-deadline"
        break
    row = index["arms"][i]
    row.update(status="launched", startedAt=datetime.now(timezone.utc).isoformat())
    checkpoint()
    command = [sys.executable, "-B", str(repo / "evaluation" / script), str(source),
               "--provider", preset, "--timeout", "30", "--max-calls", "1", "--live",
               "--output", str(run / arm)]
    if arm == "responses":
        command += ["--tactic", "independent", "--reasoning-effort", "low", "--max-output-tokens", "1024"]
    try:
        process = subprocess.run(command, cwd=repo, capture_output=True, timeout=remaining)
        row["exitCode"] = process.returncode
        row["status"] = "completed" if process.returncode == 0 else "failed"
        row["stderrPresent"] = bool(process.stderr)
    except subprocess.TimeoutExpired:
        row["status"] = "unknown-outcome"
        row["exitCode"] = None
    report_path = run / arm / "report.json"
    if report_path.exists():
        raw = report_path.read_bytes()
        report = json.loads(raw)
        assert report["mode"] == "live" and report["maxCalls"] == 1 and report["calls"] <= 1
        row.update(report={"path": arm + "/report.json", "sha256": hashlib.sha256(raw).hexdigest()},
                   reservedRequests=report["calls"], requestEntries=len(report["requests"]),
                   records={name: r["status"] for name, r in report["records"].items()})
    row["finishedAt"] = datetime.now(timezone.utc).isoformat()
    checkpoint()
    print(json.dumps({"arm": arm, "status": row["status"], "reservedRequests": row.get("reservedRequests")} ), flush=True)
    if row["status"] != "completed":
        index["stopReason"] = "first-failure-or-unknown"
        break
index["wallSeconds"] = round(time.monotonic() - started, 6)
index["finishedAt"] = datetime.now(timezone.utc).isoformat()
index["status"] = "completed" if all(r["status"] == "completed" for r in index["arms"]) else "stopped"
checkpoint()
print(json.dumps({"status": index["status"], "wallSeconds": index["wallSeconds"]}), flush=True)
